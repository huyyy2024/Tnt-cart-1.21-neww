package com.kanha.autotntcart;

import com.kanha.autotntcart.event.FlamingArrowLandHandler;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class AutoTntCartClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        FlamingArrowLandHandler.register();
        AutoTntCartMod.LOGGER.info("[AutoTntCart] Client events registered.");
    }
}
