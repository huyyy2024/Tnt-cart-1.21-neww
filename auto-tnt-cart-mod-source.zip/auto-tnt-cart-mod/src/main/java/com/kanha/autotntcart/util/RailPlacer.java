package com.kanha.autotntcart.util;

import com.kanha.autotntcart.AutoTntCartMod;
import net.minecraft.block.Blocks;
import net.minecraft.block.RailBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Set;

/**
 * Handles placing exactly one Rail and one TNT Minecart at the arrow's landing position.
 *
 * Rules:
 * - Find a solid surface at or near landPos.
 * - If a rail is already present at that surface+1, skip rail placement.
 * - If a TNT cart is already present on that rail, skip cart placement.
 * - Switch hotbar slot to rail, place, switch to TNT cart, place, restore slot.
 */
public class RailPlacer {

    /** Tracks block positions where we have already placed a rail — no double-placing. */
    private static final Set<BlockPos> PLACED_RAILS = new HashSet<>();

    public static void deploy(MinecraftClient client, BlockPos landPos) {
        if (client.player == null || client.world == null || client.interactionManager == null) return;

        World world = client.world;
        BlockPos surfacePos = findSolidSurface(world, landPos);
        if (surfacePos == null) {
            AutoTntCartMod.LOGGER.warn("[AutoTntCart] No solid surface found near {}", landPos);
            return;
        }

        BlockPos railPos = surfacePos.up();

        // --- Guard: already placed a rail here ---
        if (PLACED_RAILS.contains(railPos)) {
            AutoTntCartMod.LOGGER.info("[AutoTntCart] Rail already placed at {}, skipping.", railPos);
            return;
        }

        // --- Guard: a rail block is somehow already there ---
        if (world.getBlockState(railPos).getBlock() instanceof RailBlock) {
            AutoTntCartMod.LOGGER.info("[AutoTntCart] Existing rail at {}, skipping rail placement.", railPos);
        } else {
            // Place rail
            int railSlot = findItemInHotbar(client, Items.RAIL);
            if (railSlot == -1) {
                AutoTntCartMod.LOGGER.warn("[AutoTntCart] No Rail in hotbar.");
                return;
            }
            int prevSlot = client.player.getInventory().selectedSlot;
            client.player.getInventory().selectedSlot = railSlot;

            BlockHitResult railHit = new BlockHitResult(
                    Vec3d.ofCenter(surfacePos, 1.0),  // hit the top face of the surface block
                    Direction.UP,
                    surfacePos,
                    false
            );
            client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, railHit);

            client.player.getInventory().selectedSlot = prevSlot;
            PLACED_RAILS.add(railPos);
            AutoTntCartMod.LOGGER.info("[AutoTntCart] Rail placed at {}", railPos);
        }

        // --- Guard: TNT cart already on this rail ---
        boolean cartExists = world.getEntitiesByClass(
                TntMinecartEntity.class,
                new net.minecraft.entity.Entity.Hitbox(
                        railPos.getX() - 0.5, railPos.getY() - 0.1, railPos.getZ() - 0.5,
                        railPos.getX() + 0.5, railPos.getY() + 1.1, railPos.getZ() + 0.5
                ).toBox(),
                e -> true
        ).size() > 0;

        if (cartExists) {
            AutoTntCartMod.LOGGER.info("[AutoTntCart] TNT cart already at {}, skipping.", railPos);
            return;
        }

        // Place TNT cart — 1 tick delay so the rail block state propagates first
        client.execute(() -> placeTntCart(client, railPos, surfacePos));
    }

    private static void placeTntCart(MinecraftClient client, BlockPos railPos, BlockPos surfacePos) {
        if (client.player == null || client.world == null || client.interactionManager == null) return;

        int cartSlot = findItemInHotbar(client, Items.TNT_MINECART);
        if (cartSlot == -1) {
            AutoTntCartMod.LOGGER.warn("[AutoTntCart] No TNT Minecart in hotbar.");
            return;
        }

        int prevSlot = client.player.getInventory().selectedSlot;
        client.player.getInventory().selectedSlot = cartSlot;

        BlockHitResult cartHit = new BlockHitResult(
                Vec3d.ofCenter(railPos, 0.0),
                Direction.UP,
                railPos,
                false
        );
        client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, cartHit);

        client.player.getInventory().selectedSlot = prevSlot;
        AutoTntCartMod.LOGGER.info("[AutoTntCart] TNT Minecart placed on rail at {}", railPos);
    }

    /**
     * Walk downward from landPos up to 3 blocks to find a solid surface.
     * Returns the top solid block, or null if none found.
     */
    private static BlockPos findSolidSurface(World world, BlockPos start) {
        for (int dy = 0; dy >= -3; dy--) {
            BlockPos check = start.add(0, dy, 0);
            if (world.getBlockState(check).isSolidBlock(world, check)) {
                return check;
            }
        }
        return null;
    }

    /**
     * Returns the hotbar slot index (0-8) holding the given item, or -1.
     */
    private static int findItemInHotbar(MinecraftClient client, net.minecraft.item.Item item) {
        if (client.player == null) return -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = client.player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.getItem() == item) {
                return i;
            }
        }
        return -1;
    }
}
