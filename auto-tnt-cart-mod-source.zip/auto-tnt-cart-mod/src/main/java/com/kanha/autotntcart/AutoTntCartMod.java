package com.kanha.autotntcart;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.ArrowShotEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AutoTntCartMod implements ModInitializer {

    public static final String MOD_ID = "auto_tnt_cart";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[AutoTntCart] Mod initialized.");
        // Event registration is in the client entrypoint
    }
}
