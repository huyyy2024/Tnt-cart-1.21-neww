# Auto TNT Cart Mod
**Minecraft 1.21 · Fabric Loader 0.15.11 · Fabric API 0.100.4**

## What it does

Shoot a **Flame-enchanted bow** → arrow lands on a solid block → mod automatically:
1. Places **exactly 1 Rail** on top of that block
2. Places **exactly 1 TNT Minecart** on that rail

No duplicate rails. No duplicate carts. No leftover mess.

---

## Hotbar requirements

Before shooting, make sure your hotbar (slots 1–9) contains:
| Item | Why |
|---|---|
| `Rail` | Placed first at the landing block |
| `TNT Minecart` | Placed on the rail immediately after |

The mod scans your hotbar left-to-right and uses the **first** matching stack.

---

## How it works (internals)

```
Client tick loop
  └─ Scan ArrowEntity near player (128 block radius)
       └─ isOnFire() && isInGround() && owner == localPlayer
            └─ Not already handled (UUID set)
                 └─ findSolidSurface(landPos, search down 3 blocks)
                      └─ RailPlacer.deploy()
                           ├─ Switch hotbar to Rail slot
                           ├─ interactBlock(surfacePos, Direction.UP)   → places Rail
                           ├─ 1-tick delay (rail state propagates)
                           ├─ Switch hotbar to TNT Minecart slot
                           └─ interactBlock(railPos, Direction.UP)      → places Cart
```

---

## Build

```bash
# Requires JDK 21
./gradlew build
# Output: build/libs/auto-tnt-cart-1.0.0.jar
```

Copy the jar into your `.minecraft/mods/` folder.

---

## Notes

- Works on **singleplayer** and vanilla multiplayer where the player has permission to place blocks.
- The mod uses **standard `interactBlock` packets** — the same packets the game sends when you right-click a block.
- Processed arrow UUIDs are pruned after 64 entries to prevent memory growth.
- The `PLACED_RAILS` set resets on world unload (client session).
