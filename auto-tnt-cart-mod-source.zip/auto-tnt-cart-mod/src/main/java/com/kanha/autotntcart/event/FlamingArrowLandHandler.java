package com.kanha.autotntcart.event;

import com.kanha.autotntcart.AutoTntCartMod;
import com.kanha.autotntcart.util.RailPlacer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Each client tick:
 *  1. Scan nearby arrow entities that belong to the local player.
 *  2. If an arrow is on fire AND has landed (inGround), compute the target block.
 *  3. Delegate placement to RailPlacer — exactly 1 rail + 1 TNT cart, no duplicates.
 */
public class FlamingArrowLandHandler {

    /** UUIDs of arrows we have already processed — prevents duplicate carts. */
    private static final Set<UUID> HANDLED_ARROWS = new HashSet<>();

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.world == null || client.player == null) return;

            World world = client.world;
            UUID playerUUID = client.player.getUuid();

            // Scan every arrow entity in the world (client-side view)
            for (Entity entity : world.getEntitiesByClass(
                    ArrowEntity.class,
                    client.player.getBoundingBox().expand(128),
                    e -> true)) {

                ArrowEntity arrow = (ArrowEntity) entity;

                // Only process OUR arrows that are on fire and have landed
                if (!arrow.isOnFire()) continue;
                if (!arrow.isInGround()) continue;

                // Check owner
                Entity owner = arrow.getOwner();
                if (owner == null || !owner.getUuid().equals(playerUUID)) continue;

                UUID arrowId = arrow.getUuid();
                if (HANDLED_ARROWS.contains(arrowId)) continue;

                HANDLED_ARROWS.add(arrowId);

                // The block the arrow landed on (one block below tip position)
                BlockPos landPos = BlockPos.ofFloored(arrow.getX(), arrow.getY(), arrow.getZ());

                AutoTntCartMod.LOGGER.info("[AutoTntCart] Flaming arrow landed at {}", landPos);

                // Schedule placement on the next tick to ensure the world is ready
                scheduleCartDeploy(client, landPos);
            }

            // Prune set to avoid unbounded growth (keep last 64)
            if (HANDLED_ARROWS.size() > 64) {
                UUID first = HANDLED_ARROWS.iterator().next();
                HANDLED_ARROWS.remove(first);
            }
        });
    }

    private static void scheduleCartDeploy(MinecraftClient client, BlockPos landPos) {
        // We use a 1-tick delayed runnable via the client's execute queue
        client.execute(() -> RailPlacer.deploy(client, landPos));
    }
}
